package com.alathaniraq.tv.ui

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import com.alathaniraq.tv.databinding.ActivityOrientationSetupBinding
import com.alathaniraq.tv.util.Prefs

class OrientationSetupActivity : BaseActivity() {

    private lateinit var binding: ActivityOrientationSetupBinding
    private var selected: String = Prefs.ORIENTATION_LANDSCAPE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrientationSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        selected = Prefs.getPreferredOrientation(this)

        binding.optionLandscape.setOnClickListener { select(Prefs.ORIENTATION_LANDSCAPE) }
        binding.optionPortrait.setOnClickListener { select(Prefs.ORIENTATION_PORTRAIT) }
        // Explicit initial D-pad focus for TV/TV-box remotes.
        binding.optionLandscape.requestFocus()

        binding.previousButton.setOnClickListener {
            startActivity(Intent(this, LanguageSetupActivity::class.java))
            finish()
        }

        binding.finishButton.setOnClickListener {
            Prefs.setPreferredOrientation(this, selected)
            Prefs.setOnboardingComplete(this, true)
            startActivity(Intent(this, HomeScreenRouter.launcherActivityClass(this)))
            finish()
        }

        refreshSelection()
    }

    private fun select(orientation: String) {
        selected = orientation
        refreshSelection()
        // Live-preview the choice immediately — but only on TV, where orientation is
        // actually locked (see BaseActivity). On phones/tablets, forcing a rotation
        // here would fight the device's real physical orientation and undo itself the
        // moment BaseActivity re-applies SCREEN_ORIENTATION_USER on the next screen, so
        // we just show the selection highlighted instead of rotating anything.
        if (com.alathaniraq.tv.util.DeviceUtils.isTvDevice(this)) {
            requestedOrientation = if (orientation == Prefs.ORIENTATION_PORTRAIT) {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            } else {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }
        }
    }

    private fun refreshSelection() {
        binding.optionLandscape.isActivated = selected == Prefs.ORIENTATION_LANDSCAPE
        binding.optionPortrait.isActivated = selected == Prefs.ORIENTATION_PORTRAIT
    }
}
