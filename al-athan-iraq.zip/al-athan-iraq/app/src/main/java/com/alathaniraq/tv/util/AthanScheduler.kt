package com.alathaniraq.tv.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.alathaniraq.tv.data.Timings
import java.util.Calendar

object AthanScheduler {

    private val PRAYER_ORDER = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")

    /** Schedules an alarm for each remaining prayer time today. Call once timings are fetched. */
    fun scheduleToday(context: Context, timings: Timings) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val map = mapOf(
            "Fajr" to timings.fajr,
            "Dhuhr" to timings.dhuhr,
            "Asr" to timings.asr,
            "Maghrib" to timings.maghrib,
            "Isha" to timings.isha
        )

        val now = Calendar.getInstance()

        PRAYER_ORDER.forEachIndexed { index, name ->
            val hm = map[name] ?: return@forEachIndexed
            val parts = hm.split(":")
            if (parts.size < 2) return@forEachIndexed
            val hour = parts[0].toIntOrNull() ?: return@forEachIndexed
            val minute = parts[1].take(2).toIntOrNull() ?: return@forEachIndexed

            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            // Skip prayers that have already passed today.
            if (target.before(now)) return@forEachIndexed

            val intent = Intent(context, AthanAlarmReceiver::class.java).apply {
                putExtra(AthanAlarmReceiver.EXTRA_PRAYER_NAME, name)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                index,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    target.timeInMillis,
                    pendingIntent
                )
            } catch (_: SecurityException) {
                // Exact alarm permission not granted on this device/OS version; silently skip.
            }
        }
    }
}
