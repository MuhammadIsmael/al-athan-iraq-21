package com.alathaniraq.tv.ui

import android.content.Context
import com.alathaniraq.tv.util.Prefs

/**
 * Four home screen designs share this app: Classic (MainActivity), Dashboard
 * (DashboardMainActivity), Analog (AnalogMainActivity — an analog clock face with the
 * date curved around the rim), and Light (LightMainActivity — a light-themed layout
 * with arch-shaped prayer cards and a scrolling verse ticker). Splash and all four
 * home activities call this to agree on which one should be showing right now, based
 * on the Settings > Change Home Screen preference.
 */
object HomeScreenRouter {
    fun launcherActivityClass(context: Context): Class<*> {
        return when (Prefs.getHomeScreenMode(context)) {
            Prefs.HOME_MODE_CLASSIC -> MainActivity::class.java
            Prefs.HOME_MODE_ANALOG -> AnalogMainActivity::class.java
            Prefs.HOME_MODE_LIGHT -> LightMainActivity::class.java
            else -> DashboardMainActivity::class.java
        }
    }
}
