package com.alathaniraq.tv.util

import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import com.alathaniraq.tv.data.HijriDate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateFormatting {

    /**
     * Locale.ENGLISH alone isn't always enough — some Android builds still substitute
     * Eastern Arabic-Indic (or Kurdish-context) digits for dates/times formatted with
     * SimpleDateFormat/String.format when the app's active Configuration locale is
     * Arabic or Kurdish, regardless of which Locale object is passed in. Explicitly
     * requesting the "latn" (Latin/Western) numbering system via this BCP-47 tag is
     * the reliable fix — every digit-producing format call in this file uses it.
     */
    val WESTERN_DIGITS = Locale.forLanguageTag("en-US-u-nu-latn")

    fun gregorianToday(): String {
        val sdf = SimpleDateFormat("EEEE, d MMMM yyyy", WESTERN_DIGITS)
        return sdf.format(Date())
    }

    /** Formats the Hijri date object returned by the Aladhan API, e.g. "12 Rabi' al-awwal 1448 AH". */
    fun formatHijri(hijri: HijriDate): String {
        return "${hijri.day} ${hijri.month.en} ${hijri.year} AH"
    }

    /**
     * Dashboard home-screen date line combining Gregorian + weekday + Hijri, e.g.
     * "15 August, 2026 - Saturday - 2 Rabi Al-Awwal, 1448" (matches the reference design).
     */
    fun dashboardDateLine(hijri: HijriDate): String {
        val datePart = SimpleDateFormat("d MMMM, yyyy", WESTERN_DIGITS).format(Date())
        val weekday = SimpleDateFormat("EEEE", WESTERN_DIGITS).format(Date())
        return "$datePart - $weekday - ${hijri.day} ${hijri.month.en}, ${hijri.year}"
    }

    /** Live wall-clock time with seconds, 12-hour format, e.g. "05:30:35 PM". */
    fun currentClockTime(): String {
        return SimpleDateFormat("hh:mm:ss a", WESTERN_DIGITS).format(Date())
    }

    /** Converts a 24-hour "HH:mm" (optionally with seconds) string to 12-hour "hh:mm a". */
    fun to12Hour(time24: String): String {
        val parts = time24.take(5).split(":")
        if (parts.size != 2) return time24
        var hour = parts[0].toIntOrNull() ?: return time24
        val minute = parts[1]
        val suffix = if (hour >= 12) "PM" else "AM"
        if (hour == 0) hour = 12 else if (hour > 12) hour -= 12
        return String.format(WESTERN_DIGITS, "%02d:%s %s", hour, minute, suffix)
    }

    /** Adds [minutes] to a 24-hour "HH:mm" time string, wrapping around midnight if needed. */
    fun addMinutes(time24: String, minutes: Int): String {
        val parts = time24.take(5).split(":")
        if (parts.size != 2) return time24
        val hour = parts[0].toIntOrNull() ?: return time24
        val minute = parts[1].toIntOrNull() ?: return time24
        val total = (hour * 60 + minute + minutes).mod(24 * 60)
        return String.format(WESTERN_DIGITS, "%02d:%02d", total / 60, total % 60)
    }

    /**
     * Renders a time string ending in "AM"/"PM" with that suffix at half size, matching
     * the reference design's typography (e.g. "05:33:30" large, "PM" small). Safe to call
     * on strings that don't end in AM/PM — returns them unchanged (just as a Spannable).
     */
    fun withSmallAmPm(time: String, scale: Float = 0.55f): Spannable {
        val spannable = SpannableString(time)
        if (time.length >= 2 && (time.endsWith("AM") || time.endsWith("PM"))) {
            spannable.setSpan(
                RelativeSizeSpan(scale),
                time.length - 2,
                time.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return spannable
    }

    /**
     * Header date lines for the Light home screen, e.g. Arabic:
     * "الجمعة، 15 ربيع الأول 1448 هـ" / "الجمعة 28 أغسطس 2026 م" — weekday and
     * Gregorian month names follow the app's *current* language (unlike the other
     * date helpers above, which are always English), since this design's reference
     * shows fully localized dates. Hijri month name uses the API's Arabic name for
     * Arabic and Kurdish (no Kurdish-specific name exists), English otherwise.
     */
    fun lightHeaderDates(context: android.content.Context, hijri: HijriDate): Pair<String, String> {
        val locale = Locale.getDefault()
        val weekday = SimpleDateFormat("EEEE", locale).format(Date())
        val gregorianMonth = SimpleDateFormat("MMMM", locale).format(Date())
        val day = SimpleDateFormat("d", WESTERN_DIGITS).format(Date())
        val year = SimpleDateFormat("yyyy", WESTERN_DIGITS).format(Date())
        val hijriMonthName = if (locale.language == "ar" || locale.language == "ckb") hijri.month.ar else hijri.month.en

        val sep = context.getString(com.alathaniraq.tv.R.string.date_separator)
        val hijriSuffix = context.getString(com.alathaniraq.tv.R.string.hijri_suffix)
        val gregorianSuffix = context.getString(com.alathaniraq.tv.R.string.gregorian_suffix)

        val hijriLine = "$weekday$sep${hijri.day} $hijriMonthName ${hijri.year} $hijriSuffix"
        val gregorianLine = "$weekday $day $gregorianMonth $year $gregorianSuffix"
        return hijriLine to gregorianLine
    }
}
