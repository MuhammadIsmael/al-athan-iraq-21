package com.alathaniraq.tv.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * A hand-drawn analog clock face matching the "mosque display" reference design: a
 * teal face inside a thick gold ring, the Gregorian/Hijri date curved along the top
 * of the ring, white numerals, black hour/minute hands, and a gold second hand.
 * Ticks the second hand once a second — the parent Activity calls invalidate() on its
 * existing 1-second tick loop (see AnalogMainActivity), no internal Handler here.
 */
class AnalogClockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** The curved date/Hijri line shown along the top of the gold ring. */
    var dateText: String = ""
        set(value) {
            field = value
            invalidate()
        }

    var faceColor: Int = Color.parseColor("#1AA394")
        set(value) { field = value; invalidate() }
    var ringColor: Int = Color.parseColor("#D4AF37")
        set(value) { field = value; invalidate() }
    var numeralColor: Int = Color.WHITE
        set(value) { field = value; invalidate() }
    var dateTextColor: Int = Color.WHITE
        set(value) { field = value; invalidate() }
    var hourHandColor: Int = Color.BLACK
        set(value) { field = value; invalidate() }
    var minuteHandColor: Int = Color.BLACK
        set(value) { field = value; invalidate() }
    var secondHandColor: Int = Color.parseColor("#D4AF37")
        set(value) { field = value; invalidate() }

    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val numeralPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.LEFT
        isFakeBoldText = true
    }
    private val hourHandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val minuteHandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val secondHandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Enforce a square shape no matter which layout this is used in:
        // - Landscape (ConstraintLayout, 0dp x 0dp + constraintWidth/Height_max +
        //   1:1 ratio): the solver already hands both dimensions in EXACTLY and
        //   already equal, so this is a no-op there.
        // - Portrait (plain LinearLayout, match_parent width + fixed height): width
        //   comes in as whatever's actually available (which shrinks on narrow
        //   phones) and height as the fixed target size — taking the smaller of the
        //   two keeps the clock square and guarantees it never overflows a narrow
        //   screen, while still reaching the full intended size whenever there's
        //   room for it.
        val widthSize = MeasureSpec.getSize(widthMeasureSpec)
        val heightSize = MeasureSpec.getSize(heightMeasureSpec)
        val resolved = if (widthSize > 0 && heightSize > 0) min(widthSize, heightSize) else max(widthSize, heightSize)
        setMeasuredDimension(resolved, resolved)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f
        // Leave headroom so the curved date text (which sits just outside the ring)
        // isn't clipped by the view's bounds.
        val outerRadius = min(w, h) / 2f * 0.82f
        val ringWidth = outerRadius * 0.14f
        val faceRadius = outerRadius - ringWidth

        facePaint.color = faceColor
        ringPaint.color = ringColor
        numeralPaint.color = numeralColor
        datePaint.color = dateTextColor
        hourHandPaint.color = hourHandColor
        minuteHandPaint.color = minuteHandColor
        secondHandPaint.color = secondHandColor
        centerDotPaint.color = hourHandColor

        // Outer gold ring, then the teal face on top of it.
        canvas.drawCircle(cx, cy, outerRadius, ringPaint)
        canvas.drawCircle(cx, cy, faceRadius, facePaint)

        drawCurvedDate(canvas, cx, cy, outerRadius, ringWidth)
        drawTicks(canvas, cx, cy, faceRadius)
        drawNumerals(canvas, cx, cy, faceRadius)
        drawHands(canvas, cx, cy, faceRadius)

        centerDotPaint.color = Color.BLACK
        canvas.drawCircle(cx, cy, faceRadius * 0.035f, centerDotPaint)
    }

    private fun drawCurvedDate(canvas: Canvas, cx: Float, cy: Float, outerRadius: Float, ringWidth: Float) {
        if (dateText.isEmpty()) return
        val arcRadius = outerRadius - ringWidth / 2f
        // Base multiplier increased 15% (0.62 -> ~0.713) per request.
        datePaint.textSize = ringWidth * 0.713f

        val oval = RectF(cx - arcRadius, cy - arcRadius, cx + arcRadius, cy + arcRadius)
        val path = Path()
        // 200°..340° sweeps across the TOP of the circle (Android's 0° = 3 o'clock,
        // angles increase clockwise; 270° = 12 o'clock), leaving a little margin past
        // the horizontal so the text doesn't run into the sides.
        path.addArc(oval, 200f, 140f)

        // Center the text along the arc's length rather than anchoring it to the start.
        val measure = PathMeasure(path, false)
        val arcLength = measure.length
        val textWidth = datePaint.measureText(dateText)
        val hOffset = ((arcLength - textWidth) / 2f).coerceAtLeast(0f)

        canvas.drawTextOnPath(dateText, path, hOffset, ringWidth * 0.22f, datePaint)
    }

    private fun drawTicks(canvas: Canvas, cx: Float, cy: Float, faceRadius: Float) {
        for (i in 0 until 60) {
            val isHourTick = i % 5 == 0
            val angle = Math.toRadians((i * 6 - 90).toDouble())
            val outer = faceRadius * 0.92f
            val inner = faceRadius * (if (isHourTick) 0.82f else 0.87f)
            tickPaint.color = numeralColor
            tickPaint.strokeWidth = faceRadius * (if (isHourTick) 0.02f else 0.012f)
            val x1 = cx + outer * cos(angle).toFloat()
            val y1 = cy + outer * sin(angle).toFloat()
            val x2 = cx + inner * cos(angle).toFloat()
            val y2 = cy + inner * sin(angle).toFloat()
            canvas.drawLine(x1, y1, x2, y2, tickPaint)
        }
    }

    private fun drawNumerals(canvas: Canvas, cx: Float, cy: Float, faceRadius: Float) {
        numeralPaint.textSize = faceRadius * 0.22f
        val numeralRadius = faceRadius * 0.68f
        for (i in 1..12) {
            val angle = Math.toRadians((i * 30 - 90).toDouble())
            val x = cx + numeralRadius * cos(angle).toFloat()
            // Vertically center the digit on its baseline.
            val y = cy + numeralRadius * sin(angle).toFloat() - (numeralPaint.ascent() + numeralPaint.descent()) / 2f
            canvas.drawText(i.toString(), x, y, numeralPaint)
        }
    }

    private fun drawHands(canvas: Canvas, cx: Float, cy: Float, faceRadius: Float) {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR)
        val minute = cal.get(Calendar.MINUTE)
        val second = cal.get(Calendar.SECOND)

        val secondAngle = second * 6f
        val minuteAngle = minute * 6f + second * 0.1f
        val hourAngle = (hour % 12) * 30f + minute * 0.5f

        hourHandPaint.strokeWidth = faceRadius * 0.045f
        minuteHandPaint.strokeWidth = faceRadius * 0.03f
        secondHandPaint.strokeWidth = faceRadius * 0.015f

        drawHand(canvas, cx, cy, hourAngle, faceRadius * 0.48f, hourHandPaint)
        drawHand(canvas, cx, cy, minuteAngle, faceRadius * 0.68f, minuteHandPaint)
        drawHand(canvas, cx, cy, secondAngle, faceRadius * 0.74f, secondHandPaint)
    }

    private fun drawHand(canvas: Canvas, cx: Float, cy: Float, angleDeg: Float, length: Float, paint: Paint) {
        val angleRad = Math.toRadians((angleDeg - 90).toDouble())
        val endX = cx + length * cos(angleRad).toFloat()
        val endY = cy + length * sin(angleRad).toFloat()
        canvas.drawLine(cx, cy, endX, endY, paint)
    }
}
